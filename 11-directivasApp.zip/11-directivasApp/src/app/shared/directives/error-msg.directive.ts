import {
  Directive,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';

@Directive({
  selector: '[error-msg]',
})
export class ErrorMsgDirective implements OnInit, OnChanges {
  private _color: string = 'red';
  private _message: string = 'required';

  htmlElement: ElementRef<HTMLElement>;
  //@Input() color: string = 'red';
  //@Input() message: string = 'Campo requerido';

  @Input() set color(value: string) {
    //this.htmlElement.nativeElement.style.color = value;
    this.setColor();
    this._color = value;
  }
  @Input() set message(value: string) {
    //this.htmlElement.nativeElement.innerText = value;
    this.setMessage();
    this._message = value;
  }

  @Input() set valido(value: boolean) {
    if (value) {
      this.htmlElement.nativeElement.classList.add('hidden');
    } else {
      this.htmlElement.nativeElement.classList.remove('hidden');
    }
  }

  constructor(private el: ElementRef<HTMLElement>) {
    //console.log(el);
    this.htmlElement = el;
    //el.nativeElement.style.color = 'red';
  }

  ngOnChanges(changes: SimpleChanges): void {
    // console.log(changes);
    // if (changes['message']) {
    //   const currentMessage = changes['message'].currentValue;
    //   this.htmlElement.nativeElement.innerText = currentMessage;
    // }
    // if (changes['color']) {
    //   const color = changes['color'].currentValue;
    //   this.htmlElement.nativeElement.style.color = color;
    // }
  }

  ngOnInit(): void {
    //console.log(this.color); //undefined
    //console.log(this.message); //undefined
    this.setColor();
    this.setMessage();
    this.setStyle();
  }

  setStyle(): void {
    this.htmlElement.nativeElement.classList.add('form-text');
  }

  setColor(): void {
    this.htmlElement.nativeElement.style.color = this._color;
  }

  setMessage(): void {
    this.htmlElement.nativeElement.innerText = this._message;
  }
}
