const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const path = require("path");
const { dbConnection } = require("./db/config");
require("dotenv").config();

const app = express();
dbConnection();

//middlares
app.use(express.static("public"));
app.use(morgan("combined"));
app.use(cors());
app.use(express.json());

//paths
app.use("/api/auth", require("./routes/auth"));

//manejar rutas restantes
app.get("*", (req, res) => {
  res.sendFile(path.resolve(__dirname, "public/index.html"));
});

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});
