const { Router } = require("express");
const { check } = require("express-validator");
const {
  crearUsuario,
  loginUsuario,
  revalidarToken,
} = require("../controllers/auth");
const { validarCampos } = require("../middlewares/validar-campos");
const { validarJWT } = require("../middlewares/validar-jwt");

const router = Router();

router.post(
  "/new",
  [
    check("name", "Username es requerido")
      .notEmpty()
      .isAlphanumeric()
      .isLength({ min: 4 }),
    check("email", "Email es requerido").isEmail().notEmpty(),
    check("password", "Clave es requerido").isLength({ min: 6 }).notEmpty(),
    validarCampos,
  ],
  crearUsuario
);

router.post(
  "/",
  [
    check("email", "Email es requerido").isEmail().notEmpty(),
    check("password", "Clave es requerido").isLength({ min: 6 }).notEmpty(),
    validarCampos,
  ],
  loginUsuario
);

router.get("/renew", [validarJWT], revalidarToken);

module.exports = router;
