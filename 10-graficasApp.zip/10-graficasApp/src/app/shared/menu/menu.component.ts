import { Component, OnInit } from '@angular/core';

interface IMenuItem {
  path: string;
  name: string;
}
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styles: [
    `
      li {
        cursor: pointer;
      }
    `,
  ],
})
export class MenuComponent {
  menu: IMenuItem[] = [
    { path: '/graficas/barra', name: 'Barras' },
    { path: '/graficas/barra-doble', name: 'Barras Dobles' },
    { path: '/graficas/dona', name: 'Dona' },
    { path: '/graficas/dona-http', name: 'Dona Http' },
  ];
}
