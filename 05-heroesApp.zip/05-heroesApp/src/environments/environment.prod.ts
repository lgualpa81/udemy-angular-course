export const environment = {
  production: true,
  baseUrl: 'http://prod:3000'
};
