import { Component, Input, OnInit } from '@angular/core';
import { IHeroe } from '../../interfaces/heroe.interface';

@Component({
  selector: 'app-heroe-tarjeta',
  templateUrl: './heroe-tarjeta.component.html',
  styles: [],
})
export class HeroeTarjetaComponent {
  //@Input() heroe: IHeroe | undefined;
  @Input() heroe!: IHeroe;
}
