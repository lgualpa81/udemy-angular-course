import { Pipe, PipeTransform } from '@angular/core';
import { IHeroe } from '../interfaces/heroe.interface';

@Pipe({
  name: 'imagen',
  //pure: false //pendiente a los cambios en el ciclo de angular
})
export class ImagenPipe implements PipeTransform {
  transform({ id, alt_img }: IHeroe): string {
    //console.log("Pipe imagen procesado");
    return !id && !alt_img
      ? `assets/no-image.png`
      : alt_img ?? `assets/heroes/${id}.jpg`;
  }
}
