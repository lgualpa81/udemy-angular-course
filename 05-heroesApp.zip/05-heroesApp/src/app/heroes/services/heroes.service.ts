import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

import { IHeroe } from '../interfaces/heroe.interface';

@Injectable({
  providedIn: 'root',
})
export class HeroesService {
  private baseUrl: string = environment.baseUrl;

  constructor(private http: HttpClient) {}
  getHeroes(): Observable<IHeroe[]> {
    return this.http.get<IHeroe[]>(`${this.baseUrl}/heroes`);
  }

  getHeroePorId(id: string): Observable<IHeroe> {
    return this.http.get<IHeroe>(`${this.baseUrl}/heroes/${id}`);
  }

  getSugerencias(termino: string): Observable<IHeroe[]> {
    return this.http.get<IHeroe[]>(
      `${this.baseUrl}/heroes?q=${termino}&_limit=6`
    );
  }

  agregarHeroe(heroe: IHeroe): Observable<IHeroe> {
    return this.http.post<IHeroe>(`${this.baseUrl}/heroes`, heroe);
  }

  editarHeroe(heroe: IHeroe): Observable<IHeroe> {
    return this.http.put<IHeroe>(`${this.baseUrl}/heroes/${heroe.id}`, heroe);
  }

  eliminarHeroe(id: string): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/heroes/${id}`);
  }
}
