export interface IAuth {
  id: string;
  email: string;
  usuario: string;
}
