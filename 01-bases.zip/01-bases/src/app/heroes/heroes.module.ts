import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HeroeComponent } from './heroe/heroe.component';
import { ListadoComponent } from './listado/listado.component';

@NgModule({
  //que componentes, pipes tiene el modulo
  declarations: [HeroeComponent, ListadoComponent],
  //que cosas deben ser publicas
  exports: [ListadoComponent],
  //van los modulos que se definen
  imports: [
    //permite inyectar las directivas perrsonalizadas de angular ngFor, ngif, etc
    CommonModule,
  ],
})
export class HeroesModule {}
