import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ContadorModule } from './contador/contador.module';
import { DbzModule } from './dbz/dbz.module';
import { HeroesModule } from './heroes/heroes.module';

@NgModule({
  //se definen los componentes
  declarations: [AppComponent],
  //se colocan los modulos a usar
  imports: [BrowserModule, ContadorModule, HeroesModule, DbzModule],
  providers: [], //son servicios especificos a un modulo
  bootstrap: [AppComponent], //componente principal a lanzar primero
})
export class AppModule {}
