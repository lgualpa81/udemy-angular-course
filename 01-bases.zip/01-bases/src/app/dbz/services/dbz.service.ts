import { Injectable } from '@angular/core';
import { Personaje } from '../interfaces/dbz.interface';

@Injectable()
export class DbzService {
  private _personajes: Personaje[] = [
    {
      nombre: 'Goku',
      poder: 15000,
    },
    {
      nombre: 'Vegeta',
      poder: 7500,
    },
  ];

  constructor() {
    console.log('servicio dbz inicializado');
  }

  //getter
  get personajes(): Personaje[] {
    //Para romper la referencia de js, crear un nuevo array
    return [...this._personajes];
  }

  agregarPersonaje(data: Personaje) {
    this._personajes.push(data);
  }
}
