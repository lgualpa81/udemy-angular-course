export interface Personaje {
  nombre: string;
  poder: number;
}
