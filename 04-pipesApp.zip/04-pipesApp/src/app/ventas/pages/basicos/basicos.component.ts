import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basicos',
  templateUrl: './basicos.component.html',
  styles: [],
})
export class BasicosComponent {
  nombreLower: string = 'jon';
  nombreUpper: string = 'JON';
  nombreCompleto: string = 'JoN wIcK';

  fecha: Date = new Date();
  epoch: number = Date.now();
}
