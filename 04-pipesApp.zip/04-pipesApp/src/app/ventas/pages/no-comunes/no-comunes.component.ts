import { Component, OnInit } from '@angular/core';
import { interval } from 'rxjs';

@Component({
  selector: 'app-no-comunes',
  templateUrl: './no-comunes.component.html',
  styles: [],
})
export class NoComunesComponent {
  //i18nSelect
  nombre: string = 'Joe';
  genero: string = 'masculino';

  invitacionMapa = {
    masculino: 'invitarlo',
    femenino: 'invitarla',
  };

  //i18nPlural
  clientes: string[] = ['Maria', 'Pedro', 'Julia', 'Tom'];
  clientesMapa = {
    '=0': 'no tenemos ningún cliente esperando.',
    '=1': 'tenemos un cliente esperando.',
    other: 'tenemos # clientes esperando.',
  };

  cambiarCliente() {
    this.nombre = 'Susan';
    this.genero = 'femenino';
  }

  borrarCliente() {
    this.clientes.pop();
  }

  //keyvalue Pipe
  persona = {
    nombre: 'Joe',
    edad: 30,
    direccion: 'Riobamba, EC',
  };

  //jsonPipe
  heroes = [
    { nombre: 'Superman', vuela: true },
    { nombre: 'Ironman', vuela: true },
    { nombre: 'Flash', vuela: false },
  ];

  //AsyncPipe
  miObservable = interval(1000); //0,1,2,3

  valorPromesa = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('Fin promesa');
    }, 3500);
  });
}
