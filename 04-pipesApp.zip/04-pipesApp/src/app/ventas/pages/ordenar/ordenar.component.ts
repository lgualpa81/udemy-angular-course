import { Component, OnInit } from '@angular/core';
import { Color, Heroe } from '../../interfaces/ventas.interface';

@Component({
  selector: 'app-ordenar',
  templateUrl: './ordenar.component.html',
  styles: [],
})
export class OrdenarComponent {
  upper: boolean = true;
  ordenarPor: string = '';

  heroes: Heroe[] = [
    { nombre: 'Superman', vuela: true, color: Color.azul },
    {
      nombre: 'Batman',
      vuela: false,
      color: Color.negro,
    },
    {
      nombre: 'Ironman',
      vuela: true,
      color: Color.rojo,
    },
  ];

  cambioUpper() {
    this.upper = !this.upper;
  }

  cambiarOrden(valor: string) {
    this.ordenarPor = valor;
  }
}
