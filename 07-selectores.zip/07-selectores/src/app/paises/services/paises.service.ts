import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { combineLatest, Observable, of } from 'rxjs';
import { Country, ShortCountry } from '../pages/interfaces/pais.interface';

@Injectable({
  providedIn: 'root',
})
export class PaisesService {
  private _apiUrl = 'https://restcountries.com/v3.1';
  private _regions: string[] = [
    'africa',
    'americas',
    'asia',
    'europe',
    'oceania',
  ];

  get regions(): string[] {
    return [...this._regions];
  }

  get httpParams() {
    return new HttpParams().set('fields', 'name,cca2');
  }

  constructor(private http: HttpClient) {}

  getCountriesByRegion(region: string): Observable<Country[]> {
    const url: string = `${this._apiUrl}/region/${region}`;
    return this.http.get<Country[]>(url, { params: this.httpParams });
  }

  getCountryByCode(code: string): Observable<Country[] | null> {
    if (!code) {
      return of(null);
    }
    const url: string = `${this._apiUrl}/alpha/${code}`;
    return this.http.get<Country[]>(url);
  }

  getShortCountryByCode(code: string): Observable<ShortCountry> {
    const url: string = `${this._apiUrl}/alpha/${code}`;
    return this.http.get<ShortCountry>(url, { params: this.httpParams });
  }

  getCountriesByListCode(codes: string[]): Observable<ShortCountry[]> {
    if (!codes) {
      return of([]);
    }

    const requests: Observable<ShortCountry>[] = [];
    codes.forEach((alphaCode) => {
      const country_request = this.getShortCountryByCode(alphaCode);
      requests.push(country_request);
    });
    return combineLatest(requests);
  }
}
