import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { switchMap, tap } from 'rxjs/operators';
import { PaisesService } from '../../services/paises.service';
import { Country, ShortCountry } from '../interfaces/pais.interface';

@Component({
  selector: 'app-selector-page',
  templateUrl: './selector-page.component.html',
  styles: [],
})
export class SelectorPageComponent implements OnInit {
  //selects
  regions: string[] = [];
  countries: Country[] = [];
  //countryBorders: string[] = [];
  countryBorders: ShortCountry[] = [];

  //UI
  loading: boolean = false;

  selectorForm: FormGroup = this.fb.group({
    region: ['', [Validators.required]],
    pais: ['', [Validators.required]],
    //frontera: [{ value: '', disabled: true }, [Validators.required]],
    frontera: ['', [Validators.required]],
  });

  constructor(private fb: FormBuilder, private paisesSvc: PaisesService) {}

  ngOnInit(): void {
    this.regions = this.paisesSvc.regions;

    // this.selectorForm.get('region')?.valueChanges.subscribe((region) => {
    //   this.paisesSvc.getCountriesByRegion(region).subscribe((countries) => {
    //     this.countries = countries;
    //   });
    // });

    //select region
    this.selectorForm
      .get('region')
      ?.valueChanges.pipe(
        tap((_) => {
          this.loading = true;
          this.selectorForm.get('pais')?.reset('');
          //this.selectorForm.get('frontera')?.disable();
        }), //reset al 2do select
        switchMap((region) => this.paisesSvc.getCountriesByRegion(region))
      )
      .subscribe((countries) => {
        this.countries = countries;
        this.loading = false;
      });

    //select pais
    this.selectorForm
      .get('pais')
      ?.valueChanges.pipe(
        tap(() => {
          this.countryBorders = [];
          this.loading = true;
          this.selectorForm.get('frontera')?.reset('');
          //this.selectorForm.get('frontera')?.enable();
        }),
        switchMap((country_code) =>
          this.paisesSvc.getCountryByCode(country_code)
        ),
        switchMap((country) => {
          const codes: string[] = country ? country[0].borders : [];
          return this.paisesSvc.getCountriesByListCode(codes);
        })
      )
      .subscribe((countries) => {
        //this.countryBorders = country ? country[0].borders : [];

        this.countryBorders = countries;
        this.loading = false;
      });
  }

  guardar() {
    console.log(this.selectorForm.value);
  }
}
