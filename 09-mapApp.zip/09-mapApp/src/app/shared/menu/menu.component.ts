import { Component, OnInit } from '@angular/core';

interface IMenuItem {
  path: string;
  name: string;
}

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styles: [
    `
      li {
        cursor: pointer;
      }
    `,
  ],
})
export class MenuComponent {
  menuItems: IMenuItem[] = [
    {
      name: 'Fullscreen',
      path: '/maps/fullscreen',
    },
    {
      name: 'Zoom range',
      path: '/maps/zoom-range',
    },
    {
      name: 'Bookmarks',
      path: '/maps/bookmarks',
    },
    {
      name: 'Propiedades',
      path: '/maps/propiedades',
    },
  ];

  constructor() {}
}
