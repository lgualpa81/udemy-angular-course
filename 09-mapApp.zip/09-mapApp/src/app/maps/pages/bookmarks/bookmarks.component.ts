import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import * as mapboxgl from 'mapbox-gl';

interface IColorMarker {
  color: string;
  marker?: mapboxgl.Marker;
  center?: [number, number];
}
@Component({
  selector: 'app-bookmarks',
  templateUrl: './bookmarks.component.html',
  styles: [
    `
      .map-container {
        height: 100%;
        width: 100%;
      }
      .list-group {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 999;
      }
      li {
        cursor: pointer;
      }
    `,
  ],
})
export class BookmarksComponent implements AfterViewInit {
  map!: mapboxgl.Map;
  @ViewChild('mapId') divMap!: ElementRef;
  zoomLevel: number = 15;
  position: [number, number] = [-78.515276775932, -0.22039690650441854];

  markers: IColorMarker[] = [];

  constructor() {}

  ngAfterViewInit(): void {
    this.map = new mapboxgl.Map({
      container: this.divMap.nativeElement, // container ID
      style: 'mapbox://styles/mapbox/streets-v12', // style URL
      center: this.position, // starting position [lng, lat]
      zoom: this.zoomLevel, // starting zoom
    });

    this.getMarkersfromLocalStorage();
    // const marketHtml: HTMLElement = document.createElement('div');
    // marketHtml.innerHTML = 'hola mundo'
    //const marker = new mapboxgl.Marker({element: marketHtml})

    // const marker = new mapboxgl.Marker()
    //   .setLngLat(this.position)
    //   .addTo(this.map);
  }

  addMarker() {
    const color = '#xxxxxx'.replace(/x/g, (y) =>
      ((Math.random() * 16) | 0).toString(16)
    );
    const newMarker = new mapboxgl.Marker({
      draggable: true,
      color,
    })
      .setLngLat(this.position)
      .addTo(this.map);

    this.markers.push({ color, marker: newMarker });
    this.saveMarkersLocalStorage();

    newMarker.on('dragend', () => {
      this.saveMarkersLocalStorage();
    });
  }

  goMarker(marker: mapboxgl.Marker) {
    this.map.flyTo({
      center: marker.getLngLat(),
    });
  }

  deleteMarker(i: number) {
    this.markers[i].marker?.remove();
    this.markers.splice(i, 1);
    this.saveMarkersLocalStorage();
  }

  saveMarkersLocalStorage() {
    const lngLatArr: IColorMarker[] = [];
    this.markers.forEach((m) => {
      const color: string = m.color;
      const { lng, lat } = m.marker!.getLngLat();

      lngLatArr.push({ color: color, center: [lng, lat] });
    });

    sessionStorage.setItem('markers', JSON.stringify(lngLatArr));
  }

  getMarkersfromLocalStorage() {
    if (!sessionStorage.getItem('markers')) return;

    const lngLatArr: IColorMarker[] = JSON.parse(
      sessionStorage.getItem('markers')!
    );
    lngLatArr.forEach((m) => {
      const newMarker = new mapboxgl.Marker({
        color: m.color,
        draggable: true,
      })
        .setLngLat(m.center!)
        .addTo(this.map);

      this.markers.push({
        marker: newMarker,
        color: m.color,
      });

      newMarker.on('dragend', () => {
        this.saveMarkersLocalStorage();
      });
    });
  }
}
