import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Country } from '../interfaces/pais.interfaces';

@Injectable({
  providedIn: 'root',
})
export class PaisService {
  private _apiUrl = 'https://restcountries.com/v3.1';

  get httpParams() {
    return new HttpParams().set('fields', 'name,capital,cca2,flags,population');
  }

  constructor(private http: HttpClient) {}

  buscarPais(termino: string): Observable<Country[]> {
    const url = `${this._apiUrl}/name/${termino}`;
    return this.http.get<Country[]>(url, { params: this.httpParams });
  }

  buscarCapital(capital: string): Observable<Country[]> {
    const url: string = `${this._apiUrl}/capital/${capital}`;
    return this.http.get<Country[]>(url, {params: this.httpParams});
  }

  buscarCountryByCode(code: string): Observable<Country[]> {
    const url: string = `${this._apiUrl}/alpha/${code}`;
    return this.http.get<Country[]>(url);
  }

  searchRegion(region: string): Observable<Country[]> {
    const url: string = `${this._apiUrl}/region/${region}`;
    return this.http
      .get<Country[]>(url, { params: this.httpParams });
  }
}
