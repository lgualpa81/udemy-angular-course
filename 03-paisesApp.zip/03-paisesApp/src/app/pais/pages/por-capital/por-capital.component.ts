import { Component, OnInit } from '@angular/core';
import { Country } from '../../interfaces/pais.interfaces';
import { PaisService } from '../../services/pais.service';

@Component({
  selector: 'app-por-capital',
  templateUrl: './por-capital.component.html',
  styleUrls: ['./por-capital.component.css'],
})
export class PorCapitalComponent {
  termino: string = '';
  foundError: boolean = false;
  countries: Country[] = [];

  constructor(private paisService: PaisService) {}

  buscar(termino: string) {
    this.termino = termino;
    this.foundError = false;
    this.paisService.buscarCapital(this.termino).subscribe({
      next: (paises) => {
        //console.log(paises);
        this.countries = paises;
      },
      error: (err) => {
        this.foundError = true;
        console.log('Error');
        console.log(err);
        this.countries = [];
      },
    });
  }

}
