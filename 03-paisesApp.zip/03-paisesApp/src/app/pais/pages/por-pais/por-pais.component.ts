import { Component, OnInit } from '@angular/core';
import { Country } from '../../interfaces/pais.interfaces';
import { PaisService } from '../../services/pais.service';

@Component({
  selector: 'app-por-pais',
  templateUrl: './por-pais.component.html',
  styleUrls: ['./por-pais.component.css'],
})
export class PorPaisComponent {
  termino: string = '';
  foundError: boolean = false;
  countries: Country[] = [];

  paisesSugeridos: Country[] = [];
  mostrarSugerencias:boolean = false;

  constructor(private paisService: PaisService) {}

  buscar(termino: string) {
    this.termino = termino;
    this.foundError = false;
    this.mostrarSugerencias = false;
    
    this.paisService.buscarPais(this.termino).subscribe({
      next: (paises) => {
        //console.log(paises);
        this.countries = paises;
      },
      error: (err) => {
        this.foundError = true;
        console.log('Error');
        console.log(err);
        this.countries = [];
      },
    });
  }

  sugerencias(termino: string) {
    this.foundError = false;
    this.termino = termino;
    this.mostrarSugerencias = true;

    this.paisService.buscarPais(termino).subscribe({
      next: (paises) => (this.paisesSugeridos = paises.splice(0, 5)),
      error: (err) => (this.paisesSugeridos = []),
    });
  }
}
