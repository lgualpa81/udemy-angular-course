import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { switchMap, tap } from 'rxjs/operators';
import { Country } from '../../interfaces/pais.interfaces';
import { PaisService } from '../../services/pais.service';

@Component({
  selector: 'app-ver-pais',
  templateUrl: './ver-pais.component.html',
  styleUrls: ['./ver-pais.component.css'],
})
export class VerPaisComponent implements OnInit {
  pais!:Country;
  Object=Object;

  constructor(
    private activateRoute: ActivatedRoute,
    private paisService: PaisService
  ) {}

  ngOnInit(): void {
    // this.activateRoute.params
    // .subscribe(({ countryid }) => {
    //   console.log(countryid);
    //   this.paisService.buscarCountryByCode(countryid)
    //   .subscribe((pais) => {
    //     console.log(pais);
    //   });
    // });

    this.activateRoute.params
      .pipe(
        switchMap(({ countryid }) =>
          this.paisService.buscarCountryByCode(countryid)
        ),
        //tap(console.log)
      )
      .subscribe((pais) => {
        console.log(pais);
        this.pais = pais[0];
      });
  }
}
