import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Gif, SearchGifsResponse } from '../interfaces/gifs.interface';

@Injectable({
  providedIn: 'root', //angular eleva a un nivel global de la app
})
export class GifsService {
  private _apiKey: string = 'FrR7bwBf76z8cTP4Ai9dmaKJBa07R17e';
  private _baseUrl: string = 'https://api.giphy.com/v1/gifs';
  private _historial: string[] = [];

  get historial() {
    return [...this._historial];
  }

  public resultados: Gif[] = [];

  constructor(private http: HttpClient) {
    this._historial = JSON.parse(sessionStorage.getItem('historial')!) || [];
    this.resultados = JSON.parse(sessionStorage.getItem('resultados')!) || [];
  }

  buscarGifs(query: string) {
    query = query.trim().toLowerCase();

    if (!this._historial.includes(query)) {
      this._historial.unshift(query); //al inicio del arreglo
      this._historial = this._historial.splice(0, 10);

      sessionStorage.setItem('historial', JSON.stringify(this._historial));
    }
    //console.log(this._historial);

    //el modulo http trabaja con observables
    const params = new HttpParams()
      .set('api_key', this._apiKey)
      .set('q', query)
      .set('limit', '10');

    this.http
      .get<SearchGifsResponse>(`${this._baseUrl}/search`, { params })
      .subscribe((resp) => {
        //console.log(resp.data);
        this.resultados = resp.data;

        sessionStorage.setItem('resultados', JSON.stringify(this.resultados));
      });
  }
}
