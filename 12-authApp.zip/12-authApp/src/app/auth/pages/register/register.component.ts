import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styles: [],
})
export class RegisterComponent {
  registerForm: FormGroup = this.fb.group({
    name: ['leo', [Validators.required]],
    email: ['leo@demo.com', [Validators.required, Validators.email]],
    password: ['123456', [Validators.required, Validators.minLength(6)]],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authSvc: AuthService
  ) {}

  register() {
    const { name, email, password } = this.registerForm.value;
    this.authSvc.register(name, email, password).subscribe((auth) => {
      if (auth === true) {
        this.router.navigateByUrl('/dashboard');
      } else {
        Swal.fire('Error', auth || '', 'error');
      }
    });
    //this.router.navigateByUrl('/dashboard');
  }
}
