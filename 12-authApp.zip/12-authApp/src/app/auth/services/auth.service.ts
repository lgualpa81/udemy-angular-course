import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { IAuthResponse, IUser } from '../interfaces/auth.interface';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private _baseUrl: string = environment.baseUrl;
  private _user!: IUser;

  //getter
  get user() {
    return { ...this._user };
  }

  constructor(private http: HttpClient) {}

  register(name: string, email: string, password: string): Observable<boolean> {
    const url: string = `${this._baseUrl}/auth/new`;
    return this.http.post<IAuthResponse>(url, { name, email, password }).pipe(
      tap(({ ok, token }) => {
        if (ok) {
          sessionStorage.setItem('token', token!);
        }
      }),
      map((auth) => auth.ok),
      catchError((err) => of(err.error.msg))
    );
  }

  login(email: string, password: string): Observable<boolean> {
    return this.http
      .post<IAuthResponse>(`${this._baseUrl}/auth`, {
        email,
        password,
      })
      .pipe(
        tap((auth) => {
          if (auth.ok) {
            sessionStorage.setItem('token', auth.token!);
          }
        }),
        map((auth) => auth.ok),
        catchError((err) => of(err.error.msg))
      );
  }

  checkToken(): Observable<boolean> {
    const url: string = `${this._baseUrl}/auth/renew`;
    const headers = new HttpHeaders().set(
      'x-token',
      sessionStorage.getItem('token') || ''
    );
    return this.http.get<IAuthResponse>(url, { headers }).pipe(
      map((auth) => {
        sessionStorage.setItem('token', auth.token!);
        this._user = {
          name: auth.name!,
          uid: auth.uid!,
          email: auth.email!,
        };
        return auth.ok;
      }),
      catchError((err) => of(false))
    );
  }

  logout() {
    sessionStorage.clear();
  }
}
