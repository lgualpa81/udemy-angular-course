export interface IAuthResponse {
  ok: boolean;
  uid?: string;
  name?: string;
  token?: string;
  email?: string;
  msg?: string;
}

export interface IUser {
  uid: string;
  name: string;
  email: string;
}
