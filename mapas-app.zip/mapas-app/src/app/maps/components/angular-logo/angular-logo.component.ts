import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-logo',
  templateUrl: './angular-logo.component.html',
  styleUrls: ['./angular-logo.component.css']
})
export class AngularLogoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
