import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmailValidatorService } from '../../../shared/validator/email-validator.service';
import { ValidatorService } from '../../../shared/validator/validator.service';
// import {
//   emailPattern,
//   existsUsername,
//   fullnamePattern,
// } from '../../../shared/validator/validaciones';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styles: [],
})
export class RegistroComponent implements OnInit {
  registerForm: FormGroup = this.fb.group(
    {
      nombre: [
        '',
        [
          Validators.required,
          Validators.pattern(this.validatorSvc.fullnamePattern),
        ],
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(this.validatorSvc.emailPattern),
        ],
        [this.emailSvc],
      ],
      username: ['', [Validators.required, this.validatorSvc.existsUsername]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      password2: ['', [Validators.required]],
    },
    {
      validators: [this.validatorSvc.isDiff('password', 'password2')],
    }
  );

  get emailErrors(): string {
    const errors = this.registerForm.get('email')?.errors;
    if (errors?.['required']) {
      return 'Email es requerido';
    } else if (errors?.['pattern']) {
      return 'Formato incorrecto';
    } else if (errors?.['exists']) {
      return 'Email ya esta registrado.';
    }
    return '';
  }

  constructor(
    private fb: FormBuilder,
    private validatorSvc: ValidatorService,
    private emailSvc: EmailValidatorService
  ) {}

  ngOnInit(): void {
    this.registerForm.reset({
      nombre: 'Joe Doe',
      email: 'info@demo.com',
      username: 'joedoe',
    });
  }

  invalidField(field: string) {
    return (
      this.registerForm.get(field)?.invalid &&
      this.registerForm.get(field)?.touched
    );
  }

  hasErrors(field: string, typeValidator: string): boolean {
    return (
      this.registerForm.controls[field].errors?.[typeValidator] &&
      this.registerForm.get(field)?.touched
    );
  }

  submitForm() {
    console.log(this.registerForm.value);
    this.registerForm.markAllAsTouched();
  }
}
