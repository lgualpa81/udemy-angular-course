import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-basicos',
  templateUrl: './basicos.component.html',
  styles: [],
})
export class BasicosComponent implements OnInit {
  //viewchild apunta a la referencia local del html, no es necesario el #
  @ViewChild('miFormulario') form!: NgForm;
  initForm = {
    producto:'',
    precio: 0,
    existencias: 0
  }

  constructor() {}

  ngOnInit(): void {}

  checkName(): boolean {
    return (
      this.form?.controls['producto']?.invalid &&
      this.form?.controls['producto']?.touched
    );
  }

  checkPrice(): boolean {
    return (
      this.form?.controls['precio']?.touched &&
      this.form?.controls['precio']?.value < 0
    );
  }

  // guardar(form:NgForm){
  guardar() {
    console.log(this.form);
    this.form.resetForm({ producto: '', precio: 0, existencias: 0 });
  }
}
