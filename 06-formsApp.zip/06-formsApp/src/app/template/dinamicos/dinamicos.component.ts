import { Component, OnInit } from '@angular/core';

interface IFavorito {
  id: number;
  nombre: string;
}

interface IPersona {
  nombre: string;
  favoritos: IFavorito[];
}
@Component({
  selector: 'app-dinamicos',
  templateUrl: './dinamicos.component.html',
  styles: [],
})
export class DinamicosComponent {
  newGame: string = '';

  persona: IPersona = {
    nombre: 'Joe Doe',
    favoritos: [
      { id: 1, nombre: 'Street fighter' },
      { id: 2, nombre: 'Top gear' },
    ],
  };
  agregarJuego() {
    const favorito: IFavorito = {
      id: this.persona.favoritos.length + 1,
      nombre: this.newGame,
    };

    this.persona.favoritos.push({...favorito});
    this.newGame = '';
  }

  guardar() {
    console.log('submit');
  }

  eliminar(index: number) {
    this.persona.favoritos.splice(index, 1);
  }
}
