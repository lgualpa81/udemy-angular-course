import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class ValidatorService {
  public fullnamePattern: string = '([a-zA-Z]+) ([a-zA-Z]+)';
  public emailPattern: string = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';

  constructor() {}

  existsUsername(control: FormControl): ValidationErrors | null {
    const username: string = control.value?.trim().toLowerCase();
    if (username === 'joe') {
      return {
        exists: true,
      };
    }
    return null;
  }

  isDiff(field1: string, field2: string) {
    return (control: AbstractControl): ValidationErrors | null => {
      if (control.get(field1)?.value !== control.get(field2)?.value) {
        control.get(field2)?.setErrors({ diff: true });
        return {
          diff: true,
        };
      }
      control.get(field2)?.setErrors(null);
      return null;
    };
  }
}
