import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-basicos',
  templateUrl: './basicos.component.html',
  styles: [],
})
export class BasicosComponent implements OnInit {
  // miFormulario: FormGroup = new FormGroup({
  //   nombre: new FormControl('Laptop'),
  //   precio: new FormControl(1500),
  //   existencias: new FormControl(5),
  // })

  miFormulario: FormGroup = this.fb.group({
    //campo: [valor defecto, validadores sincronos, validadores asincronos]

    nombre: [, [Validators.required, Validators.minLength(3)]],
    precio: [, [Validators.min(0), Validators.required]],
    existencias: [, [Validators.min(0), Validators.required]],
  });
  constructor(private fb: FormBuilder) {}
  ngOnInit(): void {
    //la restriccion es que todos los campos deben tener un valor por default,
    //si uno falta se produce una excepcion
    // this.miFormulario.setValue({
    //   nombre: 'Laptop',
    //   precio: 1200,
    //   existencias: 5,
    // });

    //en su lugar se recomienda usar el reset, ya que soporta campos opcionales
    this.miFormulario.reset({
      nombre: 'Laptop',
      precio: 1200,
    });
  }

  isValid(field: string) {
    return (
      this.miFormulario.controls[field].errors &&
      this.miFormulario.controls[field].touched
    );
  }

  guardar() {
    if (this.miFormulario.invalid) {
      this.miFormulario.markAllAsTouched();
      return;
    }
    console.log(this.miFormulario.value);
    this.miFormulario.reset();
  }
}
