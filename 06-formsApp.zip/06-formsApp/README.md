# FormsApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.2.10.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.


Para que routerLink="template/basicos", funcione debe estar importado el módulo

import { RouterModule } from '@angular/router';

## Template forms
La aproximación por template, angular se encarga de manejar el formulario de forma automática, y que todos los cambios que hagamos o especificaciones / configuraciones la haga del lado del html

Se debe importar modulo: FormModule para que angular tome el control de los formularios
En la definición del formulario hay que usar una referencia local # del tipo ngForm y pasarla a la funcion
<form
      (ngSubmit)="guardar(miFormulario)"
      #miFormulario="ngForm"
      autocomplete="off"
    >
Los campos del formulario deben tener las propiedades ngModel y el tener definido el name, de no tener definido el name produce una excepción ngModel además que deben ser únicos

<input
            type="text"
            class="form-control"
            ngModel
            name="producto"
            placeholder="Nombre del producto"
          />
Función que recupera los datos enviados desde el formulario
guardar(form:NgForm){
    console.log(form.value);
  }

## Reactive forms
Procura que el html sea lo más básico posible y que todas las validaciones se lo haga del lado del typescript


Se debe importar el modulo ReactiveFormsModule

Se define un formulario de tipo FormGroup

miFormulario: FormGroup = new FormGroup({
    nombre: new FormControl('Laptop'),
    precio: new FormControl(1500),
    existencias: new FormControl(5),
  })

El objeto hay enlazar al html el formulario creado, se lo hace incluyendo
[formGroup]="miFormulario" a la etiqueta form

<form (ngSubmit)="guardar()" [formGroup]="miFormulario" autocomplete="off">

En el html se debe vincular los campos del formGroup con formControlName
formControlName="nombre"

Otra alternativa es usar formBuilder que ayuda a crear formularios más complejos