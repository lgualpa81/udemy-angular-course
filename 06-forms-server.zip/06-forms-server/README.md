
npx json-server --watch db.json
